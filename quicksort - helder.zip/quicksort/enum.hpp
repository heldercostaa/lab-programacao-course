#ifndef ENUM_HPP
#define ENUM_HPP

enum enum_tipo { tipo_primeiro,
	
	VIA_INDICES,
	VIA_PONTEIROS,
//	TEMPO,
	MEMORIA,
	
tipo_ultimo };

enum enum_selecao { selecao_primeiro,
	
	FIXA,
	ALEATORIA,
	HOARE,
	BFPRT,
	
selecao_ultimo};

enum enum_particionamento { particionamento_primeiro,
	
	DUPLO,
	TRIPLO,

particionamento_ultimo };

#endif /* ENUM_HPP */
